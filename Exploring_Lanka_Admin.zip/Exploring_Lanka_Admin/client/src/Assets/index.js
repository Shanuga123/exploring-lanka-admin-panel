import logo from "./reg_logo.PNG";
import reedem from "./Reedem.png";
import revenue from "./Revenue.png";
import service from "./Service.png";
import users from "./Users.png";
import background from "./background.png";
import show from "./show.png";
import hide from "./hide.png";
import dashboard from "./dashboard.png";
import home from "./home.png";
import user from "./user.png";
import showcase from "./showcase.png";
import settings from "./settings.png";
import role from "./role.png";
import market from "./market.png";
import content from "./content.png";
import customer from "./customer.png";
import logout from "./logout.png";
import demouser from "./demo-user.png";
import see from "./see.png";
import change from "./change.png";
import remove from "./remove.png";
import search from "./search.png";

export {
  logo,
  reedem,
  revenue,
  service,
  users,
  background,
  hide,
  show,
  dashboard,
  home,
  user,
  showcase,
  settings,
  role,
  market,
  content,
  customer,
  logout,
  demouser,
  remove,
  change,
  see,
  search,
};
