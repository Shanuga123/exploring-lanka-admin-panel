export const blogCats = [
    {
      name: "Hotels",
    },
    {
      name: "Restaurants",
    },
    {
      name: "Activities",
    },
    {
      name: "Rent Vehicles",
    },
    {
      name: "Travel",
    },
    {
      name: "Foods",
    },
    {
      name: "Events",
    },
    
  ];
  
  export const vehifea = [
    {
      name: "Luxury",
    },
    {
      name: "Convertible",
    },
    {
      name: "4x4",
    },
    {
      name: "Hybird",
    },
    {
      name: "ABS (braking)",
    },
    {
      name: "Nano",
    },
    {
      name: "Budget",
    },
    {
      name: "Petrol",
    },
    {
      name: "Diesel",
    },
    {
      name: "GPS nav",
    }
  ];
  