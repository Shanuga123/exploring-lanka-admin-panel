import React, { useState, useEffect } from "react";
import Menubar from "../Components/Menubar";
import MenuToggle from "../Components/MenuToggle";
import Navbar from "../Components/Navbar";
import "../Styles/BlogPage.css";
import { search } from "../Assets/index";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";
import Loader from "../Components/Loader";

const ActivityDetails = () => {
  const [loading, setLoading] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const [searchText, setSearchText] = useState("");
  const navigate = useNavigate();
  const { listingId } = useParams();
  const [listing, setListing] = useState(null);

  const handleMenuToggle = () => {
    setShowMenu(!showMenu);
  };

  const handleSearch = (event) => {
    setSearchText(event.target.value);
  };

  const PendingActivities = () => {
    navigate("/pending-activity"); 
  };

  const AllActivities = () => {
    navigate("/all-activity"); 
  };

  

  const getListingDetails = async () => {
    try {
      const response = await fetch(
        `http://localhost:8000/activities/${listingId}`,
        {
          method: "GET",
        }
      );

      const data = await response.json();
      if (response.status === 202) {
        setListing(data);
      } else {
        console.error("activity Listing cannot be found!");
      }
      setLoading(false);
    } catch (err) {
      console.log("Fetch Listing Details Failed", err.message);
      setLoading(false);
    }
  };

  useEffect(() => {
    getListingDetails();
  }, [listingId]);

  if (loading) {
    return <Loader />;
  }

  if (!listing) {
    return <div>Blog Listing cannot be found!</div>;
  }


  const handleAccept = async () => {
    try {
      const response = await fetch(`http://localhost:8000/activities/approve/${listingId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ approve: true })
      });
      
      if (response.ok) {
        setListing({ ...listing, approve: true });
        
      } else {
        console.error("Failed to approve the activity");
      }
    } catch (err) {
      console.error("Failed to approve the activity", err.message);
    }
  };

  return (
    <div className="blog_container">
      <div
        className={`w-1/5 h-auto h-screen bg-gray-200 text-gray-500 ${
          showMenu ? "" : "hidden"
        } lg:block`}>
        <Menubar />
      </div>
      <div className="blog-part">
        <Navbar pagename={"Blogs Management"} />
        <MenuToggle showMenu={showMenu} handleMenuToggle={handleMenuToggle} />
        <div className="first-part">
          <div className="search">
            <input
              type="text"
              placeholder="Search your blog"
              onChange={handleSearch}
            />
            <img src={search} alt="search" />
          </div>
          <div className="buttons">
                <button onClick={AllActivities}>All Activities</button>
                <button onClick={PendingActivities}>Pending Activities</button>
          </div>
        </div>
        <hr />
        <div className="create-blog">
          <div className="title">
            <h1>{listing.title}</h1>
            {!listing.approve && <p className="pending-text">Pending....</p>} 
          </div>
          <div className="detail-photos">
          {listing.imgUrls?.map((photo, index) => (
              <div key={index} className="detail">
                <img
                  src={photo}
                  alt={`photo ${index + 1}`}
                /></div>))}
          </div>
          <div className="blogm">
          <h3>Description: </h3>
          <h4>{listing.description}</h4>
          </div>
          <div className="blogm">
            <h3>Address: </h3>
            <div>
            <h4>{listing.streetAddress},</h4>
            <h4>{listing.city},</h4>
            <h4>{listing.province}</h4>
            </div>
            </div>
            <div className="blogm">
            <h3>Price: </h3>
            <h4>{listing.price}</h4>
            </div>
            <div className="blogm">
            <h3>Contact Details: </h3>
            <h4>+{listing.contactNumber}</h4>
            </div>
          
          <hr />
          {!listing.approve && (
            <button onClick={handleAccept}>Accept</button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ActivityDetails;
