import React, { useEffect, useState } from "react";
import Menubar from "../Components/Menubar";
import MenuToggle from "../Components/MenuToggle";
import Navbar from "../Components/Navbar";
import "../Styles/BlogPage.css";
import { search } from "../Assets/index";
import { useNavigate, useParams } from "react-router-dom";
import { IoClose } from "react-icons/io5";
import app from '../firebase';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";

const BlogPage = () => {
  const [showMenu, setShowMenu] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [image, setImage] = useState(undefined);
  const [tags, setTags] = useState([]);
  const [categories, setCategories] = useState("");
  const [imgPerc, setImgPerc] = useState("");
  const [inputs, setInputs] = useState({});
  const [imageUploaded, setImageUploaded] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const { listingId } = useParams();

  const navigate = useNavigate();

  const handleMenuToggle = () => {
    setShowMenu(!showMenu);
  };

  const handleSearch = (event) => {
    setSearchText(event.target.value);
  };

  const [formDescription, setFormDescription] = useState({
    title: "",
    description: "",
  });

  const handleChangeDescription = (e) => {
    const { name, value } = e.target;
    setFormDescription({
      ...formDescription,
      [name]: value,
    });
  };

  const handleAddTag = (e) => {
    if (e.key === 'Enter' && e.target.value.trim() !== '') {
      setTags([...tags, e.target.value.trim()]);
      e.target.value = '';
      e.preventDefault();
    }
  };

  const handleRemoveTag = (indexToRemove) => {
    setTags(tags.filter((_, index) => index !== indexToRemove));
  };

  const showAllBlog = () => {
    navigate("/all-blog");
  };

  useEffect(() => {
    if (listingId) {
      setIsEditing(true);
      fetch(`http://localhost:8000/blogs/${listingId}`)
        .then((response) => response.json())
        .then((data) => {
          setFormDescription({
            title: data.title,
            description: data.description,
          });
          setCategories(data.categories);
          setTags(data.tags);
          setInputs({ imgUrl: data.imgUrl });
          setImageUploaded(true);
        })
        .catch((err) => console.error("Error fetching blog details", err));
    }
  }, [listingId]);

  useEffect(() => {
    if (image) {
      uploadFile(image, "imgUrl");
    }
  }, [image]);

  const uploadFile = (file, fileType) => {
    const storage = getStorage();
    const folder = "images/";
    const fileName = new Date().getTime() + file.name;
    const storageRef = ref(storage, folder + fileName);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        setImgPerc(Math.round(progress));
        switch (snapshot.state) {
          case 'paused':
            console.log('Upload is paused');
            break;
          case 'running':
            console.log('Upload is running');
            break;
          default:
            break;
        }
      },
      (error) => {
        console.log(error);
        switch (error.code) {
          case 'storage/unauthorized':
            console.log(error);
            break;
          case 'storage/canceled':
            break;
          case 'storage/unknown':
            break;
          default:
            break;
        }
      },
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          console.log('downloadURL - ', downloadURL);
          setInputs((prev) => {
            return {
              ...prev,
              [fileType]: downloadURL,
            };
          });
          setImageUploaded(true); // Set the image as uploaded
        });
      }
    );
  };

  const handlePost = async (e) => {
    e.preventDefault();

    try {
      const listingForm = new FormData();
      listingForm.append("title", formDescription.title);
      listingForm.append("description", formDescription.description);
      listingForm.append("categories", categories);
      listingForm.append("tags", tags);
      listingForm.append("imgUrl", inputs.imgUrl);

      const response = await fetch(
        `http://localhost:8000/blogs/${isEditing ? `update/${listingId}` : "create/blog"}`,
        {
          method: isEditing ? "PUT" : "POST",
          body: listingForm,
        }
      );

      if (response.ok) {
        navigate("/all-blog");
      } else {
        console.error("Failed to create/update listing");
      }
    } catch (err) {
      console.error("Publish Listing failed", err.message);
    }
  };

  const handleRemoveImage = () => {
    setImage(undefined);
    setInputs((prev) => {
      const { imgUrl, ...rest } = prev;
      return rest;
    });
    setImageUploaded(false);
    setImgPerc("");
  };

  return (
    <div className="blog_container">
      <div
        className={`w-1/5 h-auto bg-gray-200 text-gray-500 ${
          showMenu ? "" : "hidden"
        } lg:block`}
      >
        <Menubar />
      </div>
      <div className="blog-part">
        <Navbar pagename={"Blogs Management"} />
        <MenuToggle showMenu={showMenu} handleMenuToggle={handleMenuToggle} />
        <div className="first-part">
          <div className="search">
            <input
              type="text"
              placeholder="Search your blog"
              onChange={handleSearch}
            />
            <img src={search} alt="search" />
          </div>
          <div className="buttons">
            <button onClick={showAllBlog}>All Blogs</button>
            <button>{isEditing ? "Edit Blog" : "Add New Blog"}</button>
          </div>
        </div>
        <hr />
        <div className="create-blog">
          <h1>{isEditing ? "Edit Your Blog" : "Publish Your Blog"}</h1>
          <form onSubmit={handlePost}>
            <div className="content-blog">
              <p>Title</p>
              <input
                type="text"
                placeholder="Title"
                name="title"
                value={formDescription.title}
                onChange={handleChangeDescription}
                required
              />
              <p>Description</p>
              <textarea
                type="text"
                placeholder="Description"
                name="description"
                value={formDescription.description}
                onChange={handleChangeDescription}
                required
              />
              <p>Upload Photos</p>
              <div>
                <label htmlFor='img'>Your Blog Images:</label>
                {imgPerc > 0 && "Uploading: " + imgPerc + "%"}
                <br />
                {imageUploaded ? (
                  <div className="uploaded-image-container">
                    <img src={inputs.imgUrl} alt="Uploaded" width="100" />
                    <button type="button" onClick={handleRemoveImage}>
                      <IoClose />
                    </button>
                  </div>
                ) : (
                  <input
                    type="file"
                    accept="images/*"
                    id="img"
                    onChange={(e) => setImage((prev) => e.target.files[0])}
                  />
                )}
              </div>
              <p>Select your Categories</p>
              <select
                name="categories"
                value={categories}
                onChange={(e) => setCategories(e.target.value)}
                required
              >
                <option value="" disabled>Select your Categories</option>
                <option value="Hotels">Hotels</option>
                <option value="Restaurants">Restaurants</option>
                <option value="Activities">Activities</option>
                <option value="Rent Vehicles">Rent Vehicles</option>
                <option value="travel">Travel</option>
                <option value="Foods & Drinks">Foods & Drinks</option>
                <option value="Events">Events</option>
              </select>
              <p>Add Your Tags</p>
              <div className="tags-input-container">
                <div className="tag-con">
                  {tags.map((tag, index) => (
                    <div key={index} className="tag-item">
                      <span>{tag}</span>
                      <button type="button" onClick={() => handleRemoveTag(index)}>
                        <IoClose />
                      </button>
                    </div>
                  ))}
                </div>
                <input
                  type="text"
                  placeholder="Type and press enter to add tags"
                  onKeyDown={handleAddTag}
                />
              </div>
            </div>
            <button className="submit_btn" type="submit">
              {isEditing ? "Update Your Blog" : "Publish Your Blog"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default BlogPage;
