import React, { useState, useEffect } from "react";
import Menubar from "../Components/Menubar";
import MenuToggle from "../Components/MenuToggle";
import Navbar from "../Components/Navbar";
import "../Styles/BlogPage.css";
import { search } from "../Assets/index";
import { useNavigate } from "react-router-dom";
import Loader from "../Components/Loader";
import ActivityCard from "../Components/ActivityCard";


const AllActivities = () => {
const [loading, setLoading] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const [searchText, setSearchText] = useState("");
  const navigate = useNavigate();
  const [listings, setListings] = useState([]);
  
  const handleMenuToggle = () => {
    setShowMenu(!showMenu);
  };
  const handleSearch = (event) => {
    setSearchText(event.target.value);
  };

  const PendingActivities = () => {
    navigate("/pending-activity"); 
  };
 

  const getFeedListings = async () => {
    try {
      const response = await fetch(`http://localhost:8000/activities/search/all`, {
        method: "GET",
      });

      const data = await response.json();
      const approvedListings = data.filter(listing => listing.approve === true);
      setListings(approvedListings);
      setLoading(false);
    } catch (err) {
      console.log("Fetch Listings Failed", err.message);
    }
  };
  useEffect(() => {
    getFeedListings();
  }, []);

  return (
    <div className="blog_container">
      <div
        className={`w-1/5 h-auto h-screen bg-gray-200 text-gray-500 ${
          showMenu ? "" : "hidden"
        } lg:block`}>
        <Menubar />
      </div>
      <div className="blog-part">
        <Navbar pagename={"Activities Management"} />
        <MenuToggle showMenu={showMenu} handleMenuToggle={handleMenuToggle} />
        <div className="first-part">
        <div className="search">
          <input
            type="text"
            placeholder="Search your blog"
            onChange={handleSearch}
          />
          <img
            src={search}
            alt="search"
          />
        </div>
        <div className="buttons">
          <button>All Activities</button>
          <button onClick={PendingActivities}>Pending Activities</button>
        </div>
        </div>
        <hr />
        <div className="create-blog">
        {loading ? (
          <Loader />
        ) : (
          <div className="list">
            {listings.map(
              ({
                _id,
              creator,
              listingPhotoPaths,
              streetAddress,
              city,
              province,
              imgUrls,
              title,
              category,
              type,
              price,
              }) => (
                <ActivityCard
                key={_id}
                listingId={_id}
                title={title}
                streetAddress={streetAddress}
                creator={creator}
                imgUrls={imgUrls}
                listingPhotoPaths={listingPhotoPaths}
                city={city}
                province={province}
                category={category}
                type={type}
                price={price}
                />
              )
            )}
          </div>
        )}
        </div>
        </div>
    </div>
  );
};

export default AllActivities;

