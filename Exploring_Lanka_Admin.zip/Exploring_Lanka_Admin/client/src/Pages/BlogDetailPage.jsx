import React, { useState, useEffect } from "react";
import Menubar from "../Components/Menubar";
import MenuToggle from "../Components/MenuToggle";
import Navbar from "../Components/Navbar";
import "../Styles/BlogPage.css";
import { search } from "../Assets/index";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";
import Loader from "../Components/Loader";

const BlogDetailPage = () => {
  const [loading, setLoading] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const [searchText, setSearchText] = useState("");
  const navigate = useNavigate();
  const { listingId } = useParams();
  const [listing, setListing] = useState(null);

  const handleMenuToggle = () => {
    setShowMenu(!showMenu);
  };

  const handleSearch = (event) => {
    setSearchText(event.target.value);
  };

  const createNewBlog = () => {
    navigate("/create-blog");
  };

  const showAllBlog = () => {
    navigate("/all-blog");
  };

  const editBlog = () => {
    navigate(`/edit-blog/${listingId}`);
  };

  const getListingDetails = async () => {
    try {
      const response = await fetch(
        `http://localhost:8000/blogs/${listingId}`,
        {
          method: "GET",
        }
      );

      const data = await response.json();
      if (response.status === 202) {
        setListing(data);
      } else {
        console.error("Blog Listing cannot be found!");
      }
      setLoading(false);
    } catch (err) {
      console.log("Fetch Listing Details Failed", err.message);
      setLoading(false);
    }
  };

  useEffect(() => {
    getListingDetails();
  }, [listingId]);

  if (loading) {
    return <Loader />;
  }

  if (!listing) {
    return <div>Blog Listing cannot be found!</div>;
  }

  return (
    <div className="blog_container">
      <div
        className={`w-1/5 h-auto h-screen bg-gray-200 text-gray-500 ${
          showMenu ? "" : "hidden"
        } lg:block`}>
        <Menubar />
      </div>
      <div className="blog-part">
        <Navbar pagename={"Blogs Management"} />
        <MenuToggle showMenu={showMenu} handleMenuToggle={handleMenuToggle} />
        <div className="first-part">
          <div className="search">
            <input
              type="text"
              placeholder="Search your blog"
              onChange={handleSearch}
            />
            <img src={search} alt="search" />
          </div>
          <div className="buttons">
            <button onClick={showAllBlog}>All Blogs</button>
            <button onClick={createNewBlog}>Add New Blog</button>
          </div>
        </div>
        <hr />
        <div className="create-blog">
          <div className="title">
            <h1>{listing.title}</h1>
            <div className="edit-buttons">
                <button onClick={editBlog}>Edit</button>
                <button style={{background:'red'}}>Delete</button>
            </div>
          </div>
          <div className="photos">
            <img src={listing.imgUrl} alt="listing detail" />
          </div>
          <div className="blogm">
            <h3>Category : </h3>
            <h4>{listing.categories}</h4>
            </div>
          <div className="blogm">
          <h3>Tags : </h3>
            {listing.tags?.[0]?.split(",").map((item, index) => (
              <div className="facility" key={index}>
                <h4>{item}</h4>
              </div>
            ))}
          </div>
          <div className="blogm">
          <h3>Description : </h3>
          <h4>{listing.description}</h4>
          </div>
          <hr />
        </div>
      </div>
    </div>
  );
};

export default BlogDetailPage;
