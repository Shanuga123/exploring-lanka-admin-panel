import "../Styles/BlogCard.css";
import { useNavigate } from "react-router-dom";


const ProductCard = ({
    listingId,
    imgUrl,
    title,
    listingPhotoPaths,
    streetAddress,
    city,
    province,
    price,
    contactNumber,
    description,
}) => {
  const navigate = useNavigate();
    return (
      <div className="listing-container">
         <div className="listing-card"
          onClick={() => {
            navigate(`/product/detail/${listingId}`);
          }}>
          <img src={imgUrl} alt={`img`}/>
            <h3>{title}</h3>
            <p>{streetAddress}, {city}</p>
            <p>{province}</p>
            <p><span>Rs.</span>{price}</p> 
        </div>
      </div>
      
    );
  };
  
  export default ProductCard;
  