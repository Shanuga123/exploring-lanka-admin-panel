import "../Styles/BlogCard.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowForwardIos,
  ArrowBackIosNew,
} from "@mui/icons-material";


const RestaurantCard = ({
    listingId,
    creator,
    listingPhotoPaths,
    streetAddress,
    amenities,
    imgUrls,
    menuImgUrls,
    cuisines,
    styDinings,
    city,
    province,
    title,
    category,
    placeView,
    openingTime,
    closingTime,
    availabilityPeriod,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const goToPrevSlide = () => {
    setCurrentIndex(
      (prevIndex) =>
        (prevIndex - 1 + imgUrls.length) % imgUrls.length
    );
  };

  const goToNextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % imgUrls.length);
  };

  const navigate = useNavigate();
  
    return (
      <div className="listing-container">
         <div className="listing-card"
          onClick={() => {
            navigate(`/restaurant/detail/${listingId}`);
          }}>
          <div className="slider-container">
        <div
          className="slider"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {imgUrls?.map((photo, index) => (
              <div key={index} className="slide">
                <img
                  src={photo}
                  alt={`photo ${index + 1}`}
                  
                />
              <div
                className="prev-button"
                onClick={(e) => {
                  e.stopPropagation();
                  goToPrevSlide(e);
                }}
              >
                <ArrowBackIosNew sx={{ fontSize: "15px" }} />
              </div>
              <div
                className="next-button"
                onClick={(e) => {
                  e.stopPropagation();
                  goToNextSlide(e);
                }}
              >
                <ArrowForwardIos sx={{ fontSize: "15px" }} />
              </div>
            </div>
          ))}
        </div>
      </div>
            <h3>{title}</h3>
            <p>{streetAddress}, {city}</p>
            <p>{province}</p>
            <p>{availabilityPeriod}</p> 
        </div>
      </div>
      
    );
  };
  
  export default RestaurantCard;
  