import "../Styles/BlogCard.css";
import { useNavigate } from "react-router-dom";


const BlogCard = ({
    listingId,
    imgUrl,
    title,
    listingPhotoPaths,
    tags,
    categories,
}) => {

  const navigate = useNavigate();
    return (
      <div className="listing-container">
         <div className="listing-card"
         onClick={() => {
          navigate(`/blog/detail/${listingId}`);
        }}>
          <img src={imgUrl} alt={`img`}/>
            <h3>{title}</h3>
            <p>{categories}</p>
            <p>{tags}</p> 
        </div>
      </div>
      
    );
  };
  
  export default BlogCard;
  